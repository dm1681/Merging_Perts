#!/bin/bash
cd /gscratch/vsm/dm1681/san_check/sup_ear_short_circ
vplanet vpl.in
