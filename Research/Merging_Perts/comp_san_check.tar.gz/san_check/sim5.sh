#!/bin/bash
cd /gscratch/vsm/dm1681/san_check/sup_ear_long_ecc
vplanet vpl.in
