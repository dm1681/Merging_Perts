#!/bin/bash
cd /gscratch/vsm/dm1681/san_check/sup_nep_short_ecc
vplanet vpl.in
